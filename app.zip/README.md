# candidate-recommendation

Candidate Recommendation System using Collaborative Filtering
You can select to use database or excel by changing the commented lines in "GANTI SESUAI KEBUTUHAN" in app.py file